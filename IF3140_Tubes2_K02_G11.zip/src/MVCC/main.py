from cc import *

cc = CC("../../test/MVCC_test3.txt", 40)
cc.execute()